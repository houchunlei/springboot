package demo.springboot.enums;

/**
 * 业务描述：
 * 应用场景：
 *
 * @author ： houcl@missfresh.cn
 * 创建时间： 2018-12-04 20:55
 */
public enum ResultCodeEnum {
    /**
     * 0 成功
     */
    SUCCESS(0, "成功"),

    /**
     * 10001 失败
     */
    FAIL(1001, "失败"),

    /**
     * 10002 参数错误
     */
    PARAM_ERROR(1002, "参数错误"),

    /**
     * 1003 系统库存不足
     */
    OUT_OF_STOKC(1003, "系统库存不足"),

    /**
     * 1004 重复提交
     */
    REPEATED(1004, "重复提交"),


    /**
     * 10101 不存在的原料库存
     */
    NO_MATERIAL_STOCK(10101, "不存在的原料库存");

    /**
     * 返回编码
     */
    private int code;

    /**
     * 返回信息
     */
    private String msg;

    ResultCodeEnum(int code, String msg) {
        this.code = code;
        this.msg = msg;
    }

    public int getCode() {
        return code;
    }

    public String getMsg() {
        return msg;
    }
}
