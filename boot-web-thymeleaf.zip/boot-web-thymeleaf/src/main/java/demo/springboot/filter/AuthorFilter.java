package demo.springboot.filter;

import com.google.gson.Gson;
import demo.springboot.common.CommonVO;
import org.springframework.http.HttpStatus;
import org.springframework.util.StringUtils;
import org.springframework.web.filter.OncePerRequestFilter;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

/**
 * 业务描述：
 * 应用场景：
 *
 * @author ： houcl@missfresh.cn
 * 创建时间： 2018-12-03 15:30
 */
@WebFilter(urlPatterns = {"/book/*"})
public class AuthorFilter extends OncePerRequestFilter {
    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response,
                                    FilterChain chain) throws ServletException, IOException {
        String accessToken = request.getHeader("accessToken");
        if (StringUtils.isEmpty(accessToken)){
            accessToken = request.getParameter("accessToken");
        }

        if (StringUtils.isEmpty(accessToken)) {
//            logger.info("accessing to doFilterInternal1: url={}, accessToken={}", request.getRequestURI(), accessToken);
            errorHandle(response, "Token不能为空!", HttpStatus.UNAUTHORIZED.value());
            return;
        }
    }

    /**
     * token校验失败
     *
     * @param response
     * @param message
     * @param status
     * @throws IOException
     */
    public void errorHandle(HttpServletResponse response, String message, int status) throws IOException {
        response.setStatus(status);
        response.setContentType("application/json;charset=UTF-8");
        CommonVO commonVo = new CommonVO(status, message);
        String json = new Gson().toJson(commonVo);
        try (PrintWriter out = response.getWriter()) {
            out.write(json);
        }
    }
}
