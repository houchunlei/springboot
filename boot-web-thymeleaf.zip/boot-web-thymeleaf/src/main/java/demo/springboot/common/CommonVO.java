package demo.springboot.common;

import demo.springboot.enums.ResultCodeEnum;

import java.io.Serializable;

/**
 * 业务描述：
 * 应用场景：
 *
 * @author ： houcl@missfresh.cn
 * 创建时间： 2018-12-04 20:52
 */
public class CommonVO <T> implements Serializable {
    private static final long serialVersionUID = 8619815866717779991L;
    /**
     * 状态码
     */
    private int code;

    /**
     * 状态信息
     */
    private String msg;

    /**
     * 返回数据
     */
    private T data;

    public CommonVO() {
    }

    public CommonVO(int code, String msg){
        this.code = code;
        this.msg = msg;
    }

    public CommonVO(ResultCodeEnum resultCodeEnum, T data) {
        // 不允许外部实例化，只能调用静态方法
        this.code = resultCodeEnum.getCode();
        this.msg = resultCodeEnum.getMsg();
        this.data = data;
    }

    /**
     * 返回失败(通用)
     *
     * @return 结果包装类
     */
    public static CommonVO fail() {
        return new CommonVO(ResultCodeEnum.FAIL, null);
    }

    /**
     * 返回失败(具体失败原因)
     *
     * @param resultCodeEnum 失败枚举信息
     * @return 结果包装类
     */
    public static CommonVO fail(ResultCodeEnum resultCodeEnum) {
        return new CommonVO(resultCodeEnum, null);
    }

    /**
     * 返回成功(通用)
     *
     * @return 结果包装类
     */
    public static CommonVO success() {
        return new CommonVO(ResultCodeEnum.SUCCESS, null);
    }

    /**
     * 返回成功(返回数据)
     *
     * @param data 返回数据
     * @param <T>  数据类型
     * @return 结果包装类
     */
    public static <T> CommonVO success(T data) {
        return new CommonVO(ResultCodeEnum.SUCCESS, data);
    }

    /**
     * 根据枚举值判断是否成功
     *
     * @param resultCodeEnum 返回枚举信息
     * @return 结果包装类
     */
    public static CommonVO commonResult(ResultCodeEnum resultCodeEnum) {
        if (ResultCodeEnum.SUCCESS.equals(resultCodeEnum)) {
            return success();
        }
        return fail(resultCodeEnum);
    }

    /**
     * 通用返回值
     *
     * @param status 成功与否
     * @return 结果包装类
     */
    public static CommonVO commonResult(boolean status) {
        if (status) {
            return success();
        }
        return fail();
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public T getData() {
        return data;
    }

    public void setData(T data) {
        this.data = data;
    }

    @Override
    public String toString() {
        return "CommonVO{" +
                "code=" + code +
                ", msg='" + msg + '\'' +
                ", data=" + data +
                '}';
    }
}
