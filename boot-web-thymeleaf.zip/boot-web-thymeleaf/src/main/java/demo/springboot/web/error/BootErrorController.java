package demo.springboot.web.error;

import org.springframework.boot.web.servlet.error.ErrorController;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * 业务描述：
 * 应用场景：
 *
 * @author ： houcl@missfresh.cn
 * 创建时间： 2018-12-04 11:17
 */
@Controller
@RequestMapping("/error")
public class BootErrorController implements ErrorController{
    @Override
    public String getErrorPath() {
        return "error/error-404";
    }

    @RequestMapping
    public String error(){
        return getErrorPath();
    }
}
