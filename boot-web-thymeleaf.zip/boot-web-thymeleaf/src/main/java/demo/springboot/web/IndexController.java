package demo.springboot.web;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import javax.servlet.http.HttpServletResponse;

/**
 * 业务描述：
 * 应用场景：
 *
 * @author ： houcl@missfresh.cn
 * 创建时间： 2018-12-03 15:21
 */
@Controller
@RequestMapping("page")
public class IndexController {
    /**
     * 获取 Book 列表
     * 处理 "/book" 的 GET 请求，用来获取 Book 列表
     */
    @RequestMapping(value = "form", method = RequestMethod.GET)
    public String getBookList() {
        return "pages/forms/basic_elements";
    }
}
